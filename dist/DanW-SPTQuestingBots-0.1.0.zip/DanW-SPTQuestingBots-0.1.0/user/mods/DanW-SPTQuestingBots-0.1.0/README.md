Requires:
* BigBrain
* Waypoints
